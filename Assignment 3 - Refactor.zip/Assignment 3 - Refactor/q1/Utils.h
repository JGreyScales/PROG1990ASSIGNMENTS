#pragma once

//interface of util functions
// Jackson G - Prog71990 - Assignment 3 Question 1 - 2024-10-06

void smaller_of(double*, double*);