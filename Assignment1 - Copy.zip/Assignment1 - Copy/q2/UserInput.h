#pragma once

// Jackson G - prog71990 - assignment 3 - question 2 - 2024-09-29
// Interface for user facing functions (User input)

int get_int_from_user(int*);
