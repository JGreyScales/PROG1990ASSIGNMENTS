#pragma once

// Jackson G - prog71990 - assignment 3 - question 3 - 2024-09-29
// Interface for output and UTIL operations

void output_math_operations(float, float);
