#pragma once

// Jackson G - prog71990 - assignment 3 - question 3 - 2024-09-29
// Interface for user facing functions (User input)

float get_float_from_user(float*);
