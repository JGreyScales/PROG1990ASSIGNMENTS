#pragma once

// Jackson G - prog71990 - assignment 3 - question 1 - 2024-09-29
// Interface for user facing functions (User input)

int get_user_char_input(char*);
