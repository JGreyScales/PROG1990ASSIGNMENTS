#pragma once

// Jackson G - prog71990 - assignment 2 refactor - question 3 - 2024-10-16
// Interface for user facing functions (User input)

int get_int_from_user(int*);
