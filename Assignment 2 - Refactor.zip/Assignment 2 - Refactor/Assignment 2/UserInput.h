#pragma once

// Jackson G - prog71990 - assignment 2 refactor - question 1 - 2024-10-14
// Interface for user facing functions (User input)

int get_int_from_user(int*);
