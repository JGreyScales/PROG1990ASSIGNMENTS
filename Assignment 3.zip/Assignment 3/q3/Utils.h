#pragma once

// Interface for util files
// Jackson G - Prog71990 - Assignment 3 Question 3



int multiply_two_arrays_into_third(int[], int[], int, int[]);