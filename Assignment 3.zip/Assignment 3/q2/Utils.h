#pragma once

// Interface for utils
// Jackson G -- Prog71990 - Assignment 3 Question 2 - 2024-10-06

double sum_of_smallest_and_largest(double[], int);